try{Typekit.load({async:false});}
catch(e){};var _sf_startpt=(new Date()).getTime();;