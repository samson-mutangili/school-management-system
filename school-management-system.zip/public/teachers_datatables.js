
$(document).ready( function () {
    $('#teachers_details_table').DataTable();
;} );

$(document).ready( function () {
    $('#dorm_rooms_table').DataTable();
;} );

$(document).ready( function () {
    $('#dormitories_table').DataTable();
;} );

$(document).ready( function () {
    $('#student_rooms_table').DataTable();
;} );


$(document).ready( function () {
    $('#students_deatils_table').DataTable();
;} );

$(document).ready( function () {
    $('#result_slips_table').DataTable();
;} );

$(document).ready( function () {
    $('#report_disciplinary').DataTable();
;} );

$(document).ready( function () {
    $('#current_disciplinary_cases').DataTable();
;} );

$(document).ready( function () {
    $('#student_disciplinary_cases_table').DataTable();
;} );

$(document).ready( function () {
    $('#exams_table').DataTable();
    
;} );

$(document).ready( function () {
    $('#marks_entry_table').DataTable();
;} );

$(document).ready( function () {
    $('#report_forms_table').DataTable();
;} );

$(document).ready( function () {
    $('#non_teaching_staff_details_table').DataTable();
;} );


$(document).ready( function () {
    $('#alumni_non_teaching_staff_details_table').DataTable();
;} );

$(document).ready( function () {
    $('#student_classes_table').DataTable();
;} );

$(document).ready( function () {
    $('#teacher_class_table').DataTable();
;} );

$(document).ready( function () {
    $('#fee_structure_table').DataTable();
;} );

$(document).ready( function () {
    $('#take_fees_for_alumni_table').DataTable();
;} );

$(document).ready( function () {
    $('#alumni_fee_statements_table').DataTable();
;} );

$(document).ready( function () {
    $('#responsibilities_table').DataTable();
;} );

$(document).ready( function () {
    $('#fee_reports_table').DataTable();
;} );

$(document).ready( function () {
    $('#teaching_classes_table').DataTable();
;} );

