<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Student extends Model
{
    //define the table to use
    protected $table = 'students';
}
