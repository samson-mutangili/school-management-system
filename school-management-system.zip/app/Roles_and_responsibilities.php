<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Roles_and_responsibilities extends Model
{
    //
    protected $table = 'roles_and_responsibilities';
}
