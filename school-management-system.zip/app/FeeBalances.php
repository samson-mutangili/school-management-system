<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FeeBalances extends Model
{
    //define the table to use
    protected $table = 'fee_balances';
}
