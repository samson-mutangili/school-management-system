<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Teacher_classes extends Model
{
    //define table to use in the database
    protected $table = "teacher_classes";
}
