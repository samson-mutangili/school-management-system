<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Non_teaching_staff_model extends Model
{
    //define the table to use in the model
    protected $table = "non_teaching_staff";
}
