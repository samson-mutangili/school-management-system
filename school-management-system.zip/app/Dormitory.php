<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Dormitory extends Model
{
    //define the table to use
    protected $table = 'dormitories';
}
