<?php



?>

<style>
p{
    color:red; 
    font-size: 40px;
}

.hello{
    color:red; 
    font-size: 40px;
}

h1{
    color: blue;
}
</style>