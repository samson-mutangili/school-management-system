<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FeeStructureModel extends Model
{
    //define the table to use
    protected $table = "fee_structures";
}
