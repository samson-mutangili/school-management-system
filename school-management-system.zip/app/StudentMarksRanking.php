<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StudentMarksRanking extends Model
{
    //define the table to be used
    protected $table='student_marks_ranking';
}
