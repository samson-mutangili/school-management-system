<?php

?>



<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<link href= " dash/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
<link href= " https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i'" rel="stylesheet">

<link href=" dash/css/sb-admin-2.min.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href=" css/bootstrap.css">
<link rel="stylesheet" type="text/css" href=" DataTables/datatables.min.css"/>
<link rel="stylesheet" href="//cdn.datatables.net/1.10.7/css/jquery.dataTables.min.css'">
<script src=" https://code.jquery.com/-1.12.4.min.js'"></script>

<script src=" https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js'"></script>

<link href=" https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css'" rel="stylesheet">
<link rel="stylesheet" type="text/css" href=" https://cdn.datatables.net/autofill/2.3.4/css/autoFill.dataTables.min.css">
<link rel="stylesheet" type="text/css" href=" https://cdn.datatables.net/buttons/1.6.1/css/buttons.dataTables.min.css"/>

<link href=" https://cdn.datatables.net/fixedcolumns/3.3.0/css/fixedColumns.dataTables.min.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href=" https://cdn.datatables.net/colreorder/1.5.2/css/colReorder.dataTables.min.css">
<link rel="stylesheet" type="text/css" href=" https://cdn.datatables.net/fixedcolumns/3.3.0/css/fixedColumns.dataTables.min.css"/>




  <!-- Bootstrap core JavaScript-->
  <script src=" dash/vendor/jquery/jquery.min.js "></script>
  <script src=" dash/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src=" dash/vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src=" dash/js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src=" dash/vendor/chart.js/Chart.min.js"></script>

  <!-- Page level custom scripts -->
  <script src=" dash/js/demo/chart-area-demo.js"></script>
  <script src=" dash/js/demo/chart-pie-demo.js"></script>