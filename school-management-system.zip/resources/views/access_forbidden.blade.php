@extends('layouts.dashboard')

@section('content')

<P style="color: red;">You are not allowed to access the student data since no subject you are teaching in this class</P>
    
@endsection