<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Shiners high school</title>
</head>
<body>
    
    <h3>Password reset token</h3>
    <p>Use the token below to reset password</p>
    <h2>{{$token}}</h2>
    <p>Thank you.</p>
</body>
</html>