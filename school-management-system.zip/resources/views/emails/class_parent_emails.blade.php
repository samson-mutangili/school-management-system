<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Shiners high school</title>
</head>
<body>
    
    <h3>{{$details['subject']}}</h3>
    <p>Dear parent,</p>
    <p>{{$details['message_body']}}</p>
    <p>Thank you.</p>
</body>
</html>