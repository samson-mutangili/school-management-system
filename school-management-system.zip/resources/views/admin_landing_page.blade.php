@extends('layouts.dashboard')

@section('content')

<h3>Hello admin</h3>
<div class="card-columns">
        <div class="card bg-primary">
          <div class="card-body text-center">

            <i class='fas fa-graduation-cap' style='font-size:48px;color:black;'></i>
            <h3>Form 1 W</h3>
            <p>456</p>
            <p class="card-text">Some text inside the first card</p>
            <a href="#" >View</a>   
          </div>
        </div>
        <div class="card bg-warning">
          <div class="card-body text-center">

<i class='fas fa-graduation-cap' style='font-size:48px;color:black;'></i> 
<h3>Form 1 W</h3>
            <p>456</p> 
            <p class="card-text">Some text inside the second card</p>
            <a href="#" >View</a> 
          </div>
        </div>
        <div class="card bg-success">
          <div class="card-body text-center">

<i class='fas fa-graduation-cap' style='font-size:48px;color:black;'></i>
<h3>Form 1 W</h3>
            <p>456</p>
            <p class="card-text">Some text inside the third card</p>
            <a href="#" >View</a> 
          </div>
        </div>
        <div class="card bg-danger">
          <div class="card-body text-center">

<i class='fas fa-graduation-cap' style='font-size:48px;color:black;'></i>
            <h3>Form 1 W</h3>
            <p>456</p>
            <p class="card-text">Some text inside the fourth card</p>
            <a href="#" >View</a> 
          </div>
        </div>
        <div class="card bg-light">
          <div class="card-body text-center">

<i class='fas fa-graduation-cap' style='font-size:48px;color:black;'></i>
<h3>Form 1 W</h3>
            <p>456</p>
            <p class="card-text">Some text inside the fifth card</p>
            <a href="#" >View</a> 
          </div>
        </div>
        <div class="card bg-info">
          <div class="card-body text-center">

<i class='fas fa-graduation-cap' style='font-size:48px;color:black;'></i>
<h3>Form 1 W</h3>
            <p>456</p>
            <p class="card-text">Some text inside the sixth card</p>
            <a href="#" >View</a> 
          </div>
        </div>
      </div>

    
@endsection