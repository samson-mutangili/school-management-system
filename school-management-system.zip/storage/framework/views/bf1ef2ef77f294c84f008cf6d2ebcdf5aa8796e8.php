<?php $__env->startSection('content'); ?>

<div class="row">
        <div class="col-md-12">
            <h1 class="page-head-line">Student details</h1>
        </div>
</div>
<?php $i = 1;
?>

<ul class="nav nav-tabs">
        <li class="nav-item">
                <a class="nav-link active" data-toggle="tab" href="#bio_data">Bio data</a>
              </li>
    <li class="nav-item">
      <a class="nav-link " data-toggle="tab" href="#address">Address</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" data-toggle="tab" href="#parents_details">Parents details</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" data-toggle="tab" href="#result_slips">Result slips</a>
    </li>
    <li class="nav-item">
            <a class="nav-link " data-toggle="tab" href="#disciplinary_cases">Disciplinary cases</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" data-toggle="tab" href="#student_classes">Student classes</a>
          </li>
         
  </ul>



  <div style="margin-top: 15px;">
        <div style="margin-top: 15px;">
                <?php if( Session::get('student_update_successful') != null): ?>
            
                <div class="alert alert-success alert-dismissible">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong>Success</strong> : <?php echo e(Session::get('student_update_successful')); ?>

                </div>
            
                <?php endif; ?>
        </div>  

            <div style="margin-top: 15px;">
                    <?php if( Session::get('student_update_failed') != null): ?>
                
                    <div class="alert alert-danger alert-dismissible">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <strong>Failed</strong> : <?php echo e(Session::get('student_update_failed')); ?>

                    </div>
                
                    <?php endif; ?>
            </div> 
            
            <!-- show error messages for student clearance -->
            <div style="margin-top: 15px;">
                <?php if( Session::get('uncleared_cases') != null): ?>
            
                <div class="alert alert-danger alert-dismissible">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong>Failed</strong> : <?php echo e(Session::get('uncleared_cases')); ?>

                </div>
            
                <?php endif; ?>
            </div> 

        <div>
                <?php if( Session::get('address_empty_fields') != null): ?>
            
                <div class="alert alert-danger alert-dismissible">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong>Failed</strong> : <?php echo e(Session::get('address_empty_fields')); ?>

                </div>
            
                <?php endif; ?>
            </div>   
        
            <div>
                <?php if( Session::get('postal_code_error') != null): ?>
            
                <div class="alert alert-danger alert-dismissible">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong>Failed</strong> : <?php echo e(Session::get('postal_code_error')); ?>

                </div>
            
                <?php endif; ?>
            </div>  
        
            <div>
                <?php if( Session::get('postal_address_error') != null): ?>
            
                <div class="alert alert-danger alert-dismissible">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong>Failed</strong> : <?php echo e(Session::get('postal_address_error')); ?>

                </div>
            
                <?php endif; ?>
            </div>  
        
             <div>
                <?php if( Session::get('address_update_successful') != null): ?>
            
                <div class="alert alert-success alert-dismissible">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong>Success</strong> : <?php echo e(Session::get('address_update_successful')); ?>

                </div>
            
                <?php endif; ?>
            </div>  
        

            <div style="margin-top: 15px;">
                    <?php if( Session::get('same_class') != null): ?>
                
                    <div class="alert alert-danger alert-dismissible">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <strong>Failed</strong> : <?php echo e(Session::get('same_class')); ?>

                    </div>
                
                    <?php endif; ?>
                </div>  
            
                     <div style="margin-top: 15px;">
                        <?php if( Session::get('not_promoted') != null): ?>
                    
                        <div class="alert alert-danger alert-dismissible">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                <strong>Failed</strong> : <?php echo e(Session::get('not_promoted')); ?>

                        </div>
                    
                        <?php endif; ?>
                    </div> 
                    <div style="margin-top: 15px;">
                        <?php if( Session::get('promoted') != null): ?>
                    
                        <div class="alert alert-success alert-dismissible">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                <strong>Success</strong> : <?php echo e(Session::get('promoted')); ?>

                        </div>
                    
                        <?php endif; ?>
                    </div>   
             <div>
                <?php if( Session::get('address_update_failed') != null): ?>
            
                <div class="alert alert-danger alert-dismissible">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong>Failed</strong> : <?php echo e(Session::get('address_update_failed')); ?>

                </div>
            
                <?php endif; ?>
            </div>  
        
            <!-- parents update feedback messages -->
            <div>
                <?php if( Session::get('parent_empty_fields') != null): ?>
            
                <div class="alert alert-danger alert-dismissible">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong>Failed</strong> : <?php echo e(Session::get('parent_empty_fields')); ?>

                </div>
            
                <?php endif; ?>
            </div>  
        
            <div>
                <?php if( Session::get('parent_updated') != null): ?>
            
                <div class="alert alert-success alert-dismissible">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong>Success</strong> : <?php echo e(Session::get('parent_updated')); ?>

                </div>
            
                <?php endif; ?>
            </div>  
        
            <div>
                <?php if( Session::get('parent_not_updated') != null): ?>
            
                <div class="alert alert-danger alert-dismissible">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong>Failed</strong> : <?php echo e(Session::get('parent_not_updated')); ?>

                </div>
            
                <?php endif; ?>
            </div>  

            <div style="margin-top: 15px;">
                    <?php if( Session::get('message_saved') != null): ?>
                
                    <div class="alert alert-success alert-dismissible">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <strong>Success</strong> : <?php echo e(Session::get('message_saved')); ?>

                    </div>
                
                    <?php endif; ?>
            </div>  
        
                <div style="margin-top: 15px;">
                        <?php if( Session::get('no_parent') != null): ?>
                    
                        <div class="alert alert-danger alert-dismissible">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                <strong>Failed</strong> : <?php echo e(Session::get('no_parent')); ?>

                        </div>
                    
                        <?php endif; ?>
                </div> 
                <div style="margin-top: 15px;">
                    <?php if( Session::get('message_send_not_saved') != null): ?>
                
                    <div class="alert alert-success alert-dismissible">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <strong>Success</strong> : <?php echo e(Session::get('message_send_not_saved')); ?>

                    </div>
                
                    <?php endif; ?>
            </div>  
        
                <div style="margin-top: 15px;">
                        <?php if( Session::get('no_internet') != null): ?>
                    
                        <div class="alert alert-danger alert-dismissible">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                <strong>Failed</strong> : <?php echo e(Session::get('no_internet')); ?>

                        </div>
                    
                        <?php endif; ?>
                </div> 

        <div class="tab-content">
                <div id="bio_data" class="tab-pane container active">

                        <?php if(!$student_details->isEmpty()): ?>
                        <?php $__currentLoopData = $student_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $student_id = $student->id;
                        $className = $student->stream; ?>
                        <div class="panel panel-primary w-auto" >
                            <div class="panel-heading">
                              Student personal details
                            </div>  
                            
                            
                            
                            <div class="panel-body">
                                     
                                    <div class="row">
                    
                                            <div class="col-xm-12 col-sm-6 col-md-4 col-lg-3 col-xl-3">
                                                    <?php if($student->profile_pic != null): ?>
                                                      <img class="img-profile rounded-circle" style="width: 170px; height: 170px;" src="<?php echo e(URL::asset('images/'.$student->profile_pic)); ?>" alt="profile picture" />
                                                    <?php else: ?>
                                                    <img class="img-profile rounded-circle" style="width: 170px; height: 170px;" src="<?php echo e(URL::asset('images/default_profile_pic.png')); ?>" alt="profile picture" />
                    
                                                    <?php endif; ?>
                                                   
                                                   
                                            </div>
                    
                                            <div class="col-xm-12 col-sm-6 col-md-8 col-lg-9 col-xl-9">
                    
                                                <div class="row">
                                            <div class="col-md-6 col-lg-6 col-xl-6 ">
                                                    <table>
                                                            <tbody>
                                                                <tr>
                                                                    <td align="left">Admission number  </td> 
                                                                    <td> : <?php echo e($student->admission_number); ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <td align="left">Class</td>
                                                                    <td> : <?php echo e($student->stream); ?></td>
                                                                </tr>
                    
                                                                
                                                                    <tr>
                                                                        <td align="left">Date of admission  </td> 
                                                                        <td> : <?php echo e($student->date_of_admission); ?></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td align="left">Date of birth</td>
                                                                        <td> : <?php echo e($student->DOB); ?></td>
                                                                    </tr>
                                                                    <tr>
                                                                            <td align="left">Religion</td>
                                                                            <td> : <?php echo e($student->religion); ?></td>
                                                                        </tr>
                                                               
                                                            </tbody>
                                                        </table>
                                            </div>
                                            <div class="col-md-6 col-lg-6 col-xl-6 ">
                                                    <table>
                                                            <tbody>
                                                                <tr>
                                                                    <td align="left">Name</td>
                                                                    <td> : <?php echo e($student->first_name); ?> <?php echo e($student->middle_name); ?> <?php echo e($student->last_name); ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <td align="left">Gender   </td>
                                                                    <td> : <?php echo e($student->gender); ?></td>
                                                                </tr>
                    
                                                                        <tr>
                                                                            <td align="left">Birth cert no  </td> 
                                                                            <td> : <?php echo e($student->birth_cert_no); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td align="left">KCPE index no</td>
                                                                            <td> : <?php echo e($student->kcpe_index_no); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                                <td align="left">Status</td>
                                                                                <td <?php if($student->status == 'active'): ?> style="color: green;" <?php endif; ?>> : <?php echo e($student->status); ?></td>
                                                                            </tr>
                                                                    
                                                            </tbody>
                                                        </table>
                                        
                                            </div>
                                            </div>
                    
                                        <a href="/students/edit/<?php echo e($student->id); ?>" >Edit student details</a>
                                    </div>
                                           
                                        </div>
                            </div>
                        </div>
                       
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    <?php endif; ?>
                      
                    
                    <div style="margin-top: 15px;" class="row">
                        <div class="col-sm-12 col-md-6 col-lg-4 col-xl-4" style="margin-bottom: 15px;">
                                <button name="promote" id="promote" data-toggle="modal" data-target="#promote<?php echo e($student_id); ?>"  class="btn btn-outline-primary">Promote to next class</button>
                        </div>
                    
                        <div class="col-sm-12 col-md-6 col-lg-4 col-xl-4" style="margin-bottom: 15px;">
                                <button name="clear_btn" id="<?php echo e($student_id); ?>" data-toggle="modal" data-target="#clear_student<?php echo e($student_id); ?>"  class="btn btn-outline-danger">Student clearance</button>
                        </div>
                        <div class="col-sm-12 col-md-6 col-lg-4 col-xl-4" style="margin-bottom: 15px;">
                            <button name="send_mail" id="sendMail<?php echo e($student_id); ?>" data-toggle="modal" data-target="#sendMailModal<?php echo e($student_id); ?>"  class="btn btn-outline-success">Send email to parent(s)</button>
                        </div>
                    
                    
                    </div>
                    <!-- modal dialog form for promoting student to next class -->
                    <div class="container">
                        <div class="row">
                            <div class="col-xs-12 col-lg-12 col-xl-12">
                                <div class="modal" id="promote<?php echo e($student_id); ?>" tabindex="-1">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title pull-left" >Promote student to next class</h4>
                                                <button class="close" data-dismiss="modal">&times;</button>
                                            </div>
                                            <div class="modal-body">
                                                <?php
                                                    //get the current year
                                                    $year = date("Y"); 
                                                ?>
                                                
                                                            <form action="/students/promote" method = "POST" name="promote_to_next_class">
                                                                <?php echo csrf_field(); ?>
                                                                <input type="hidden" name="student_id" value="<?php echo e($student_id); ?>"/>
                                                                <input type="hidden" name="class_name" value="<?php echo e($className); ?>"/>
                    
                                                                <?php if($className == "1E" || $className == "1W"): ?>
                                                                     <input type="hidden" name="current_class" value="Form 1"/>
                                                                <?php endif; ?>
                    
                                                                <?php if($className == "2E" || $className == "2W"): ?>
                                                                     <input type="hidden" name="current_class" value="Form 2"/>
                                                                <?php endif; ?>
                    
                                                                <?php if($className == "3E" || $className == "3W"): ?>
                                                                    <input type="hidden" name="current_class" value="Form 3"/>
                                                                <?php endif; ?>
                    
                                                                <?php if($className == "4E" || $className == "4W"): ?>
                                                                     <input type="hidden" name="current_class" value="Form 4"/>
                                                                <?php endif; ?>
                                                             
                                                                <div class="row">
                                                                        <div class="col-xm-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                                                                                <div class="form-group" id="year_div">
                                                                                        <label class="control-table" for="year">Year</label>
                                                                                        <input type="number" name="year" id="year" class="form-control" placeholder="Enter year" value="<?php echo $year; ?>" readonly>
                                                                                        <div id="year_error"></div>
                                                                                </div>	
                                                                          </div>
                                                                    
                                                                          <div class="col-xm-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                                                                                <div class="form-group" id="trial_div">
                                                                                        <label class="control-table" for="trial">Trial</label>
                                                                                            <select id="trial" name="trial" class="form-control">
                                                                                                <option>1</option>
                                                                                                <option>2</option>
                                                                                            </select>
                                                                                            <div id="trial_error"></div>
                                                                                </div>	
                                                                          </div>
                    
                                                                          <div class="col-xm-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                                                                                <div class="form-group" id="next_class_div">
                                                                                        <label class="control-table" for="postal_code">Next class</label>
                                                                                        <select id="next_class" name="next_class" class="form-control" onchange="change_stream(this.id, 'class_stream')" required>
                                                                                            <option></option>
                                                                                            <?php if($className == "1E" || $className == "1W"): ?>
                                                                                                <option>Form 2</option>
                                                                                                <option>Form 1</option>
                                                                                            <?php endif; ?>
                    
                                                                                            <?php if($className == "2E" || $className == "2W"): ?>
                                                                                                <option>Form 3</option>
                                                                                                <option>Form 2</option>
                                                                                            <?php endif; ?>
                    
                                                                                            <?php if($className == "3E" || $className == "3W"): ?>
                                                                                                <option>Form 4</option>
                                                                                                <option>Form 3</option>
                                                                                            <?php endif; ?>
                    
                                                                                            <?php if($className == "4E" || $className == "4W"): ?>
                                                                                                <option>Form 4</option>
                                                                                            <?php endif; ?>
                                                                                            </select>
                                                                                        <div id="next_class_error"></div>
                                                                                </div>	
                                                                          </div>
                    
                                                                          <div class="col-xm-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                                                                                <div class="form-group" id="class_stream_div">
                                                                                        <label class="control-table" for="class_stream">Class stream</label>
                                                                                            <select id="class_stream" name="class_stream" class="form-control" required>
                                                                                                
                                                                                            </select>
                                                                                        <div id="class_stream_error"></div>
                                                                                </div>	
                                                                          </div>
                                              
                                                                    
                                                                </div>
                                                                    <div style="align: center;" class="pull-right">
                                                                     <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                                                                    <button type="submit" class="btn btn-success" value="Update">Update</button>
                                                                    </div>
                                                        </form>
                                                        
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    
                    <!-- modal dialog form for archiving student -->
                    <div class="container">
                        <div class="row">
                            <div class="col-xs-12 col-lg-12 col-xl-12">
                                <div class="modal" id="archive<?php echo e($student_id); ?>" tabindex="-1">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title pull-left" style="color:red;">Archive student details</h4>
                                                <button class="close" data-dismiss="modal">&times;</button>
                                            </div>
                                            <div class="modal-body">
                                                
                                                            <form action="/students/archive" method = "POST" name="archive_dialog">
                                                                <?php echo csrf_field(); ?>
                                                                <input type="hidden" name="student_id" value="<?php echo e($student_id); ?>"/>
                                                                <input type="hidden" name="class_name" value="<?php echo e($className); ?>"/>
                                                             
                                                                    <p>All student details in active classes will be disabled.
                                                                        Are you sure you want to archive student details? 
                                                                    </p>
                                                                    <div style="align: center;" class="pull-right">
                                                                     <button type="button" class="btn btn-success" data-dismiss="modal">Cancel</button>
                                                                    <button type="submit" class="btn btn-danger" value="Update">Archive</button>
                                                                    </div>
                                                        </form>
                                                        
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- modal dialog form for archiving student -->
                    <div class="container">
                        <div class="row">
                            <div class="col-xs-12 col-lg-12 col-xl-12">
                                <div class="modal" id="clear_student<?php echo e($student_id); ?>" tabindex="-1">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title pull-left" style="color:red;">Student clearance</h4>
                                                <button class="close" data-dismiss="modal">&times;</button>
                                            </div>
                                            <div class="modal-body">
                                                
                                                            <form action="/students/clear_student" method = "POST" name="student_clearance_dialog">
                                                                <?php echo csrf_field(); ?>
                                                                <input type="hidden" name="student_id" value="<?php echo e($student_id); ?>"/>
                                                                <input type="hidden" name="class_name" value="<?php echo e($className); ?>"/>
                                                             
                                                                    <p>All student details in active classes will be disabled. However, you can find the student details as an alumni.
                                                                        Are you sure you want to clear student? 
                                                                    </p>
                                                                    <div style="align: center;" class="pull-right">
                                                                     <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                                                                    <button type="submit" class="btn btn-success" value="Clear student">Clear student</button>
                                                                    </div>
                                                        </form>
                                                        
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    
                    
                    <!-- modal dialog form for archiving student -->
                    <div class="container">
                        <div class="row">
                            <div class="col-xs-12 col-lg-12 col-xl-12">
                                <div class="modal" id="sendMailModal<?php echo e($student_id); ?>" tabindex="-1">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title pull-left" >Send email to student parent(s)</h4>
                                                <button class="close" data-dismiss="modal">&times;</button>
                                            </div>
                                            <div class="modal-body">
                                                
                                                            <form action="/students/sendMail" method = "POST" name="send_mail_dialog">
                                                                <?php echo csrf_field(); ?>
                                                                <input type="hidden" name="student_id" value="<?php echo e($student_id); ?>"/>
                                                                <input type="hidden" name="class_name" value="<?php echo e($className); ?>"/>
                                                                <div class="row">
                                                                    <div class="col-xm-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                                                                            <div class="form-group" id="subject_div">
                                                                                    <label class="control-table" for="subject">Subject</label>
                                                                                    <input type="text" name="subject" id="subject" class="form-control" placeholder="Enter email subject" required>
                                                                                    <div id="subject_error"></div>
                                                                            </div>	
                                                                      </div>
                    
                                                                      <div class="col-xm-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                                                                        <div class="form-group" id="message_body_div">
                                                                                <label class="control-table" for="message_body">Message body</label>
                                                                                <textarea  name="message_body" id="message_body" class="form-control" placeholder="Enter the message to be sent here" rows="3" required></textarea>
                                                                                <div id="subject_error"></div>
                                                                        </div>	
                                                                  </div>
                                                                </div>
                                                                    <div style="align: center;" class="pull-right">
                                                                     <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                                                                    <button type="submit" class="btn btn-success" value="Clear student">Send email</button>
                                                                    </div>
                                                        </form>
                                                        
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
        
                </div>

                <div id="address" class="tab-pane container fade">
            
                        <div class="panel panel-primary w-auto" >
                                <div class="panel-heading">
                                  Student address details
                                </div>                    
                                <div class="panel-body">
                                    <?php if(!$student_address->isEmpty()): ?>
                                        <?php $__currentLoopData = $student_address; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <table>
                                                <tbody>
                                                    <tr>
                                                        <td align="left">Postal code</td>
                                                        <td> : <?php echo e($address->postal_code); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td align="left">Postal address</td>
                                                        <td> : <?php echo e($address->postal_address); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td align="left">Street</td>
                                                        <td> : <?php echo e($address->street); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td align="left">Town</td>
                                                        <td> : <?php echo e($address->town); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td align="left">Country</td>
                                                        <td> : <?php echo e($address->country); ?></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                            <br>
                                            <button name="edit" id="<?php echo e($address->id); ?>" data-toggle="modal" data-target="#edit_modal<?php echo e($address->id); ?>" style="width: 7em;" class="btn btn-outline-primary">Edit</button>
            
                                            <div class="container">
                                                    <div class="row">
                                                        <div class="col-xs-12 col-lg-12 col-xl-12">
                                                            <div class="modal" id="edit_modal<?php echo e($address->id); ?>" tabindex="-1">
                                                                <div class="modal-dialog">
                                                                    <div class="modal-content">
                                                                        <div class="modal-header">
                                                                            <h4 class="modal-title pull-left">Edit address details</h4>
                                                                            <button class="close" data-dismiss="modal">&times;</button>
                                                                        </div>
                                                                        <div class="modal-body">
                                                                            
                                                                                        <form action="/edit_address" method = "POST" name="address_form">
                                                                                            <?php echo csrf_field(); ?>
                                                                                            <input type="hidden" name="student_id" value="<?php echo e($student_id); ?>"/>
                                                                                            <input type="hidden" name="class_name" value="<?php echo e($className); ?>"/>
                                                                                            <input type="hidden" name="address_id" value="<?php echo e($address->id); ?>"/>
                                                                                         
                                                                                                      <div class="row">
                                                                                                            <div class="col-xm-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                                                                                                                  <div class="form-group" id="postal_code_div">
                                                                                                                          <label class="control-table" for="postal_code">Postal code</label>
                                                                                                                          <input type="number" name="postal_code" id="postal_code" class="form-control" placeholder="Enter postal code" value="<?php echo e($address->postal_code); ?>">
                                                                                                                          <div id="postal_code_error"></div>
                                                                                                                  </div>	
                                                                                                            </div>
                                                                                      
                                                                                                            <div class="col-xm-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                                                                                                                  <div class="form-group" id="postal_address_div">
                                                                                                                          <label class="control-table" for="postal_address">Postal address</label>
                                                                                                                          <input type="number" name="postal_address" id="postal_address" class="form-control" placeholder="Enter postal address" value="<?php echo e($address->postal_address); ?>">
                                                                                                                          <div id="postal_address_error"></div>
                                                                                                                  </div>	
                                                                                                            </div>
                                                                                      
                                                                                                            <div class="col-xm-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                                                                                                                  <div class="form-group" id="street_div">
                                                                                                                          <label class="control-table" for="street">Street</label>
                                                                                                                          <input type="text" name="street" id="street" class="form-control" placeholder="Enter street name" value="<?php echo e($address->street); ?>">
                                                                                                                          <div id="street_error"></div>
                                                                                                                  </div>	
                                                                                                            </div>
                                                                                    
                                                                                                            <div class="col-xm-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                                                                                                                    <div class="form-group" id="town_div">
                                                                                                                            <label class="control-table" for="town">Town</label>
                                                                                                                            <input type="text" name="town" id="town" class="form-control" placeholder="Enter town name" value="<?php echo e($address->town); ?>">
                                                                                                                            <div id="town_error"></div>
                                                                                                                    </div>
                                                                                                                
                                                                                                            </div>
                                                                                                            
                                                                                                            <div class="col-xm-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                                                                                                                    <div class="form-group" id="country_div">
                                                                                                                            <label for="country">Country</label>
                                                                                                                            <select id="country" name="country" class="form-control">
                                                                                                                                <option <?php if($address->country == 'Kenya'): ?> selected <?php endif; ?>>Kenya</option>
                                                                                                                                 <option <?php if($address->country == 'Uganda'): ?> selected <?php endif; ?>>Uganda</option>
                                                                                                                                 <option <?php if($address->country == 'Tanzania'): ?> selected <?php endif; ?>>Tanzania</option>
                                                                                                                                 <option <?php if($address->country == 'Somalia'): ?> selected <?php endif; ?>>Somalia</option>
                                                                                                                            </select>
                                                                                                                            <div id="country_error"></div>
                                                                                                                        </div>
                                                                                                                
                                                                                                            </div>
                                                                                                           
                                                                                                        </div>
                                                                                                
                                                                                                <div style="align: center;" class="pull-right">
                                                                                                 <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                                                                                                <button type="submit" class="btn btn-success" value="Update">Update</button>
                                                                                                </div>
                                                                                    </form>
                                                                                    
                                                                            
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                    
                                </div>
                        </div>
                   </div>
                   
                    <div id="parents_details" class="tab-pane container fade">
                                  
                        <div class="panel panel-primary w-auto" >
                                <div class="panel-heading">
                                  Student parent(s)
                                </div>                    
                                <div class="panel-body">
            
                                    <?php if(!$student_parents->isEmpty()): ?>
                                        <?php $__currentLoopData = $student_parents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <fieldset style="border: 2px solid #333; border-radius: 10px; padding: 5px; margin: 10px 0px; " >
                                                    <legend style="width: auto;"><?php echo e($parent->relation); ?> details</legend>
                                                    <table>
                                                            <tbody>
                                                                <tr>
                                                                    <td align="left">Name</td>
                                                                    <td> : <?php echo e($parent->first_name); ?> <?php echo e($parent->middle_name); ?> <?php echo e($parent->last_name); ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <td align="left">Email address</td>
                                                                    <td> : <?php echo e($parent->email); ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <td align="left">National ID no</td>
                                                                    <td> : <?php echo e($parent->id_no); ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <td align="left">Phone number</td>
                                                                    <td> : <?php echo e($parent->phone_no); ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <td align="left">Gender</td>
                                                                    <td> : <?php echo e($parent->gender); ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <td align="left">Occupation</td>
                                                                    <td> : <?php echo e($parent->occupation); ?></td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                        <br>
                                                        <button name="edit" id="<?php echo e($parent->id); ?>" data-toggle="modal" data-target="#edit_modal<?php echo e($parent->id); ?>" style="width: 7em;" class="btn btn-outline-primary">Edit</button>
                                                    </fieldset>
            
                                                    <div class="container">
                                                        <div class="row">
                                                            <div class="col-xs-12 col-lg-12 col-xl-12">
                                                                <div class="modal" id="edit_modal<?php echo e($parent->id); ?>" tabindex="-1">
                                                                    <div class="modal-dialog">
                                                                        <div class="modal-content">
                                                                            <div class="modal-header">
                                                                                <h4 class="modal-title pull-left">Edit <?php echo e($parent->relation); ?> details</h4>
                                                                                <button class="close" data-dismiss="modal">&times;</button>
                                                                            </div>
                                                                            <div class="modal-body">
                                                                                
                                                                                            <form action="/edit_parent_details" method = "POST" name="address_form">
                                                                                                <?php echo csrf_field(); ?>
                                                                                                <input type="hidden" name="relation" value="<?php echo e($parent->relation); ?>"/>
                                                                                                <input type="hidden" name="student_id" value="<?php echo e($student_id); ?>"/>
                                                                                                <input type="hidden" name="class_name" value="<?php echo e($className); ?>"/>
                                                                                                <input type="hidden" name="parent_id" value="<?php echo e($parent->id); ?>"/>
                                                                                             
                                                                                                          <div class="row">
                                                                                                                <div class="col-xm-12 col-sm-6 col-md-6 col-lg-4 col-xl-4">
                                                                                                                      <div class="form-group" id="first_name_div">
                                                                                                                              <label class="control-table" for="first_name">First name</label>
                                                                                                                              <input type="text" name="first_name" id="first_name" class="form-control" placeholder="Enter first name" value="<?php echo e($parent->first_name); ?>">
                                                                                                                              <div id="first_name_error"></div>
                                                                                                                      </div>	
                                                                                                                </div>
                                                                                          
                                                                                                                <div class="col-xm-12 col-sm-6 col-md-6 col-lg-4 col-xl-4">
                                                                                                                      <div class="form-group" id="middle_name_div">
                                                                                                                              <label class="control-table" for="middle_name">Middle name</label>
                                                                                                                              <input type="text" name="middle_name" id="middle_name" class="form-control" placeholder="Enter middle name" value="<?php echo e($parent->middle_name); ?>">
                                                                                                                              <div id="middle_name_error"></div>
                                                                                                                      </div>	
                                                                                                                </div>
                                                                                          
                                                                                                                <div class="col-xm-12 col-sm-6 col-md-6 col-lg-4 col-xl-4">
                                                                                                                      <div class="form-group" id="last_name_div">
                                                                                                                              <label class="control-table" for="street">Last name</label>
                                                                                                                              <input type="text" name="last_name" id="last_name" class="form-control" placeholder="Enter last name" value="<?php echo e($parent->last_name); ?>">
                                                                                                                              <div id="last_name_error"></div>
                                                                                                                      </div>	
                                                                                                                </div>
                                                                                        
                                                                                                                <div class="col-xm-12 col-sm-6 col-md-6 col-lg-4 col-xl-4">
                                                                                                                        <div class="form-group" id="id_no_div">
                                                                                                                                <label class="control-table" for="id_no">ID number</label>
                                                                                                                                <input type="number" name="id_no" id="id_no" class="form-control" placeholder="Enter ID number" value="<?php echo e($parent->id_no); ?>">
                                                                                                                                <div id="id_no_error"></div>
                                                                                                                        </div>
                                                                                                                    
                                                                                                                </div>
            
                                                                                                                <div class="col-xm-12 col-sm-6 col-md-6 col-lg-8 col-xl-8">
                                                                                                                        <div class="form-group" id="email_div">
                                                                                                                                <label class="control-table" for="phone_no">Email address</label>
                                                                                                                                <input type="email" name="email" id="email" class="form-control" placeholder="Enter email address" value="<?php echo e($parent->email); ?>">
                                                                                                                                <div id="email_error"></div>
                                                                                                                        </div>
                                                                                                                    
                                                                                                                </div>
            
                                                                                                                <div class="col-xm-12 col-sm-6 col-md-6 col-lg-4 col-xl-4">
                                                                                                                        <div class="form-group" id="phone_no_div">
                                                                                                                                <label class="control-table" for="phone_no">Phone number</label>
                                                                                                                                <input type="number" name="phone_no" id="phone_no" class="form-control" placeholder="Enter phone number" value="<?php echo e($parent->phone_no); ?>">
                                                                                                                                <div id="phone_no_error"></div>
                                                                                                                        </div>
                                                                                                                    
                                                                                                                </div>
            
                                                                                                                <div class="col-xm-12 col-sm-6 col-md-6 col-lg-4 col-xl-4">
                                                                                                                        <div class="form-group" id="occupation_div">
                                                                                                                                <label class="control-table" for="occupation">Occupation</label>
                                                                                                                                <input type="text" name="occupation" id="occupation" class="form-control" placeholder="Enter occupation" value="<?php echo e($parent->occupation); ?>">
                                                                                                                                <div id="occupation_error"></div>
                                                                                                                        </div>
                                                                                                                    
                                                                                                                </div>
            
                                                                                                                <div class="col-xm-12 col-sm-6 col-md-6 col-lg-4 col-xl-4">
                                                                                                                    <div class="form-group" id="gender_div">
                                                                                                                            <label for="gender">Gender</label>
                                                                                                                            <select id="gender" name="gender" class="form-control">
                                                                                                                                <option <?php if($parent->gender == 'female'): ?> selected <?php endif; ?>>Female</option>
                                                                                                                                 <option <?php if($parent->gender == 'male'): ?> selected <?php endif; ?>>Male</option>
                                                                                                                            </select>
                                                                                                                            <div id="gender_error"></div>
                                                                                                                        </div>
                                                                                                                
                                                                                                               </div>
                                                                                
                                                                                                               
                                                                                                            </div>
                                                                                                    
                                                                                                    <div style="align: center;" class="pull-right">
                                                                                                     <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                                                                                                    <button type="submit" class="btn btn-success" value="Update">Update</button>
                                                                                                    </div>
                                                                                        </form>
                                                                                        
                                                                                
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </div>
                        </div>                              
                   </div>
            
                   <div id="result_slips" class="tab-pane container fade">
                          <?php $i=1; 
                          
                            function getClass($stream){
                                
                                $class_form = "";
            
                                if($stream == "1E" || $stream == "1W"){
                                    $class_form = "Form 1";
                                } else if ($stream == "2E" || $stream == "2W"){
                                    $class_form = "Form 2";
                                } else if ($stream == "3E" || $stream == "3W"){
                                    $class_form = "Form 3";
                                } else if ($stream == "4E" || $stream == "4W"){
                                    $class_form = "Form 4";
                                }
            
                                return $class_form;
                            }
                          ?>
            
                          <div class="panel panel-primary w-auto" >
                            <div class="panel-heading">
                              Student result slips
                            </div>                    
                            <div class="panel-body">
                                <table class="table table-responsive-md table-responsive-sm table-responsive-lg table-responsive-xl" id="result_slips_table">
                                    <thead>
                                        <th>#No</th>
                                        <th>Year</th>
                                        <th>Class</th>
                                        <th>Stream</th>
                                        <th>Term</th>
                                        <th>Exam type</th>
                                        <th>Action</th>
                                    </thead>
            
                                    <tbody>
                                        
                                        <?php if(!$student_result_slips->isEmpty()): ?>
                                            <?php $__currentLoopData = $student_result_slips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result_slip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($i++); ?></td>
                                                    <td><?php echo e($result_slip->year); ?></td>
                                                    <td><?php echo getClass($result_slip->class_name); ?></td>
                                                    <td><?php echo e($result_slip->class_name); ?></td>
                                                    <td><?php echo e($result_slip->term); ?></td>
                                                    <td><?php echo e($result_slip->exam_type); ?></td>
                                                    <td>
                                                        <a href="/studentDetails/resultSlips/<?php echo e($result_slip->year); ?>/<?php echo e($result_slip->term); ?>/<?php echo e($result_slip->exam_type); ?>/<?php echo e($result_slip->student_id); ?>,<?php echo e($result_slip->class_name); ?>" target="blank">
                                                            <button class="btn btn-outline-primary btn-sm">Download</button>
                                                        </a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                        <?php endif; ?>
                                    </tbody>
            
                                </table>
                            </div>
                          </div>
            
                   </div>
            
                   <div id="disciplinary_cases" class="tab-pane container fade">
                                  
                    <div class="panel panel-primary w-auto" >
                            <div class="panel-heading">
                              Student disciplinary cases
                            </div>                    
                            <div class="panel-body">
                                    <?php if(!$student_disciplinary_cases->isEmpty()): ?>
                                        <?php $j=1;?>
                                    <table class="table table-hover table-responsive-sm table-responsive-md " id="student_disciplinary_cases_table">
                                        <thead class="active">
                                            <th width="5%">#NO</th>
                                            <th>Case category.</th>
                                            <th>Case Description</th>
                                            <th>Date reported</th>
                                            <th>Teacher who reported</th>
                                            <th>Action taken</th>
                                            <th>Date action taken</th>
                                            <th>status</th>
                                        </thead>
                    
                                        <tbody>
                                            <?php $__currentLoopData = $student_disciplinary_cases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $disciplinary_case): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($j++); ?></td>
                                                    <td><?php echo e($disciplinary_case->case_category); ?></td>
                                                    <td><?php echo e($disciplinary_case->case_description); ?></td>
                                                    <td><?php echo e($disciplinary_case->date_reported); ?></td>
                                                    <td><?php echo e($disciplinary_case->first_name); ?> <?php echo e($disciplinary_case->last_name); ?></td>
                                                    <?php if($disciplinary_case->action_taked != null): ?>
                                                      <td><?php echo e($disciplinary_case->action_taked); ?></td>
                                                    <?php else: ?>
                                                        <td>--</td>
                                                    <?php endif; ?>
            
                                                     <?php if($disciplinary_case->date_action_taken!= null): ?>
                                                      <td><?php echo e($disciplinary_case->date_action_taken); ?></td>
                                                    <?php else: ?>
                                                        <td>--</td>
                                                    <?php endif; ?>
                                                    <?php if($disciplinary_case->case_status == 'cleared'): ?>
                                                        <td style="color:green;"><?php echo e($disciplinary_case->case_status); ?></td>
                                                    <?php elseif($disciplinary_case->case_status == 'uncleared'): ?>
                                                         <td style="color:red;"><?php echo e($disciplinary_case->case_status); ?></td>
                                                    <?php else: ?>
                                                        <td><?php echo e($disciplinary_case->case_status); ?></td>
                                                    <?php endif; ?>
            
                                                    
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
            
                                    </table>
                    
                                    <?php else: ?>
                                        <p>The student has no history of disciplinary cases</p>
                                    <?php endif; ?>
                            </div>
                    </div>                              
               </div>
            
            
            <!-- tab for showing student classes -->
               <div id="student_classes" class="tab-pane container fade">
                <?php $i=1; 
                
                  
                ?>
            
                <div class="panel panel-default w-auto" >
                  <div class="panel-heading">
                    The classes students has been enrolled
                  </div>                    
                  <div class="panel-body">
                      <table class="table table-responsive-md table-responsive-sm table-responsive-lg table-responsive-xl" id="student_classes_table">
                          <thead>
                              <th>#No</th>
                              <th>Year</th>
                              <th>Class</th>
                              <th>Stream</th>
                              <th>Trial</th>
                              <th>Status</th>
                          </thead>
            
                          <tbody>
                              
                              <?php if(!$student_classes->isEmpty()): ?>
                                  <?php $__currentLoopData = $student_classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classes_attended): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <tr>
                                          <td><?php echo e($i++); ?></td>
                                          <td><?php echo e($classes_attended->year); ?></td>
                                          <td><?php echo e($classes_attended->class_name); ?></td>
                                          <td><?php echo e($classes_attended->stream); ?></td>
                                          <td><?php echo e($classes_attended->trial); ?></td>
                                          <?php if($classes_attended->status == "active"): ?>
                                            <td style="color: green;"><?php echo e($classes_attended->status); ?></td>
                                          <?php else: ?>
                                            <td><?php echo e($classes_status->trial); ?></td>
                                          <?php endif; ?>
                                      </tr>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  
                              <?php endif; ?>
                          </tbody>
            
                      </table>
                  </div>
                </div>
            
            </div>
            
            


        </div>
  </div>


       

         

  

       
<br>

    
      




    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\school-management-system\resources\views/specific_student.blade.php ENDPATH**/ ?>