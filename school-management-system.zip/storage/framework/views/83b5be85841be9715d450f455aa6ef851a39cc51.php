<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12">
        <h1 class="page-head-line">Students</h1>
    </div>
</div>
<?php $i = 1;

?>
 

<div class="panel panel-default w-auto">
    <div class="panel-heading">
      Form <?php echo e($className); ?> students
    </div>
       <div class="panel-body">

            <div>
                    <?php if( Session::get('student_cleared_successfully') != null): ?>
                
                    <div class="alert alert-success alert-dismissible">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <strong>Success</strong> : <?php echo e(Session::get('student_cleared_successfully')); ?>

                    </div>
                
                    <?php endif; ?>
            </div>   

            <div>
                    <?php if( Session::get('student_clearance_failed') != null): ?>
                
                    <div class="alert alert-danger alert-dismissible">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <strong>Failed</strong> : <?php echo e(Session::get('student_clearance_failed')); ?>

                    </div>
                
                    <?php endif; ?>
            </div>   

            <div>
                    <?php if( Session::get('student_added_successfully') != null): ?>
                
                    <div class="alert alert-success alert-dismissible">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <strong>Success</strong> : <?php echo e(Session::get('student_added_successfully')); ?>

                    </div>
                
                    <?php endif; ?>
            </div>  
       
            <table class="table table-hover table-responsive-sm table-responsive-md responsive-lg table-responsive-xl " id="students_deatils_table">
                    <thead class="active">
                        <th width="5%">#NO</th>
                        <th>Picture</th>
                        <th>ADM No.</th>
                        <th>Name</th>
                        <th>Class</th>
                        <th>Gender</th>
                    </thead>

                    <tbody>

                        <?php if(!$students->isEmpty()): ?>
                            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr data-href='/studentDetails/<?php echo e($className); ?>,<?php echo e($student->id); ?>'>
                                    <td><?php echo e($i++); ?></td>
                                    <?php if($student->profile_pic != null): ?>
                                    
                                    <td><img class="img-profile rounded-circle"  style="width: 40px; height: 40px;" src="<?php echo e(URL::asset('images/'.$student->profile_pic)); ?>" alt="Profile picture"> </td>

                                    <?php else: ?>
                                    <td><img class="img-profile rounded-circle"  style="width: 40px; height: 40px;" src="<?php echo e(URL::asset('images/default_profile_pic.png')); ?> " alt="profile_picture"></td>

                                    <?php endif; ?>
                                    <td><?php echo e($student->admission_number); ?></td>
                                    <td><?php echo e($student->first_name); ?>  <?php echo e($student->middle_name); ?>  <?php echo e($student->last_name); ?></td>
                                    <td><?php echo e($student->stream); ?></td>
                                    <td><?php echo e($student->gender); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
            </table>
       </div>
</div>

                
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\school-management-system\resources\views/student_details.blade.php ENDPATH**/ ?>